// ====================================================================================================
//
// Cloud Code for ScriptMessage, write your code here to customize the GameSparks platform.
//
// For details of the GameSparks Cloud Code API see https://docs.gamesparks.com/
//
// ====================================================================================================


Spark.setScriptData("name", "value")