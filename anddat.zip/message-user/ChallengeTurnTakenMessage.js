//Load challenge
var chal = Spark.getChallenge(Spark.getData().challenge.challengeId);

//load playerStats
var playerStats = chal.getScriptData("playerStats");

//If challenger reaches 0 or lower health while challenged has more than 0 health, challenged wins
if(playerStats[chal.getChallengerId()].currentHealth <= 0 && playerStats[chal.getChallengedPlayerIds()[0]].currentHealth > 0){
    chal.winChallenge(Spark.loadPlayer(chal.getChallengedPlayerIds()[0]));
}
//If challenged reaches 0 or lower health whole challenger has more than 0 health, challenger wins
if(playerStats[chal.getChallengedPlayerIds()[0]].currentHealth <= 0 && playerStats[chal.getChallengerId()].currentHealth > 0){
    chal.winChallenge(chal.getChallengerId());
}
//If both players reach zero or lower health, a draw is in order
if(playerStats[chal.getChallengedPlayerIds()[0]].currentHealth <= 0 && playerStats[chal.getChallengerId()].currentHealth <= 0){
    chal.drawChallenge();
} 