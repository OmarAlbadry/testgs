//Load deck
var deck = []
deck = Spark.getPlayer().getPrivateData("deck");

//Length and random number depending on length
var length = deck.length - 1;
var randNum = Math.floor(Math.random() * (length - 0 + 1));

//Retrieve random card stats from collection
var stats = Spark.runtimeCollection(deck[randNum]["tier"]).findOne({cardName: deck[randNum]["name"]});

//Construct card
randCard = {"type" : stats.cardName, "atk" : stats.attack, "hp" : stats.health, "maxHP": stats.health, "spawnCost" : stats.spawnCost, "effect": stats.effect};

//Retrieve the number of pulled cards so far
var numPulls = playerStats[pId].cardsPulled;

//Add the new card to the player hand and give it a unique name
currentHand[pId]["c" + numPulls.toString()] = randCard;

//Increment amount of cards pulled for future unique card names
playerStats[pId].cardsPulled = numPulls + 1;

//Return script with card pulled
Spark.setScriptData("result", randCard.type + " was pulled from deck");