//Load challenge
var chal = Spark.getChallenge(Spark.getData().challengeInstanceId);
//Retrieve player Id
var pId = Spark.getPlayer().getPlayerId();

//Retrieve player's details and play field
var playerStats = chal.getScriptData("playerStats");
var playField = chal.getScriptData("playField");

//If we have less than 10 mana gems
if(playerStats[pId].overallMana < 10){
    
    //Add a mana gem
    playerStats[pId].overallMana = playerStats[pId].overallMana + 1;
}


//Current mana will be filled again
playerStats[pId].currentMana = playerStats[pId].overallMana;

//Get all the cards on the player's play field
var cards = Object.keys(playField[pId]);
//Use the allowAtk function on every card
cards.forEach(allowAtk);

//Reset card pulled boolean
playerStats[pId].hasPulled = false;

//Save JSONs
chal.setScriptData("playField", playField);
chal.setScriptData("playerStats", playerStats);

//Finish player turn
chal.consumeTurn(pId);

function allowAtk(obj){
    //Set the canAtk value to true, to allow the card to attack next turn
    playField[pId][obj].canAtk = true;
}