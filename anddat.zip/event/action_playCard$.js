//Load challenge
  var chal = Spark.getChallenge(Spark.getData().challengeInstanceId);

  //Load data
  var playState = Spark.getData().playState;
  var cardName = Spark.getData().name;
  var targetName = Spark.getData().nameTarget;

  //Retrieve player stats
  var playerStats = chal.getScriptData("playerStats");


  //Retrieve player Id
  var pId = Spark.getPlayer().getPlayerId();

  //Determine enemy Id
  if(Spark.getPlayer().getPlayerId() === chal.getChallengerId()){
      //If equal to challenger, then Id is challenged[0] Id
      var opponentId = chal.getChallengedPlayerIds()[0];
  }
  else{
      //If not equal to challenger then other player Id is challenger Id
      var opponentId = chal.getChallengerId();
  }

  //Load playField
  var playField = chal.getScriptData("playField");
  //Load player play field
  var playerField = playField[pId];

  var attackingCard = playerField[cardName];

  if(attackingCard === null){
     Spark.setScriptError("Error", "Attacking card does not exist");
  }

  //Depending on playState of card
  if(playState === "attack"){
      if(attackingCard.canAtk === true){
          //If our target is the opponent, damage opponent
          if(targetName === "opponent"){
              if(playerStats[opponentId].tauntProtection === true){
                  Spark.setScriptError("Error", "There is a taunt card protecting your opponent")
              }
              else{
                  //Retrieve the playerHealth object
                  var health = playerStats[pId].currentHealth;
                  //Lower the opponent health points based on card's attack
                  playerStats[opponentId].currentHealth = playerStats[opponentId].currentHealth - attackingCard.atk;
                  //Save the health stats
                  chal.setScriptData("playerStats", playerStats);

                  Spark.setScriptData("result", cardName + " attacked opponent")
              }
          }
          else{
              //If our target is not an opponent, then we're aiming for another card

              //Retrieve opponent field
              var opponentField = playField[opponentId];
              //Retrieve target card
              var targetCard = opponentField[targetName];

              if(targetCard === null){
              Spark.setScriptError("Error", "Attacking card does not exist");
              }
              //If our attacking card has more attack than the target card hit points, destroy target card and check if
              //card is a taunt card, if it's a taunt card check for other taunt cards, if none are on playing field
              //remove player protection
              if(attackingCard.atk >= targetCard.hp){
                  delete playField[opponentId][targetName];
                  Spark.setScriptData("result", cardName + " destroyed " + targetName);

                  //Check for effect, if Taunt
                  if(targetCard.effect === "Taunt"){
                  if(checkTaunt(Object.keys(playField[opponentId]), playField[opponentId]) !== true){
                      playerStats[opponentId].tauntProtection = false;
                   }   
                  }
              }
              else {
                  //else if our attacking card cannot kill target card with one hit, lower hit points
                  playField[opponentId][targetName].hp = targetCard.hp - attackingCard.atk;
                  Spark.setScriptData("result", cardName + " hurt " + targetName);
              }

              //If our attacking card has less hit points than target card, destroy our card
              if(targetCard.atk >= attackingCard.hp){
                  delete playField[pId][cardName];
                  Spark.setScriptData("result", cardName + " was destroyed by " + targetName);
              }
              else{
                  //Else if our attacking card has more hit points than the target card's attack, then lower hit points
                  playField[pId][cardName].hp = attackingCard.hp - targetCard.atk;  
                  Spark.setScriptData("result", cardName + " was hurt by " + targetName);
              }

              if( playField[pId][cardName] !== null){
              //Disallow this card to be able to attack again this round if it still exists
              playField[pId][cardName].canAtk = false;
              }

                  //Save playing field
                 chal.setScriptData("playField", playField);
                 chal.setScriptData("playerStats", playerStats);
              }
          }
  }
  else{
      Spark.setScriptError("Error", "Card cannot attack this round")
  }

  //If instead our playsState was to heal instead of attack, we won't need to load the opponent's playField and just work
  //With this player's playField exclusively
  if(playState === "heal"){
      if(playField[pId][targetCard] !== null){
          //If targetCard has less hit points than max allowed
          if(playField[pId][targetCard].hp <= playField[pId][targetCard].maxHP){
              //Heal card by adding hit points
              playField[pId][targetCard].hp = playField[pId][targetCard].hp + 1;
              //Save playField
              chal.setScriptData("playField", playField);
          }
      }
      else{
          Spark.setScriptData("Error", "Can't find target card");
      }

  }

  //Check opponent's play field to see if any taunt cards remain
  function checkTaunt(arr,obj){
      //Loop through the array of keys of the playField object
     for(var i = 0; i < arr.length; i++ ){
         //For every key, access the 'effect' key pair and check if the effect is taunt
          if(obj[arr[i]].effect === "Taunt"){
              //if any taunt effects remain, return true and keep the tauntProtection boolean true
              return true;    
          }
     }
     //If no taunt effects remain, return false to change the tauntProtection boolean
     return false;
  }