//Get shortCode
var matchshortCode = Spark.getData().match_shortCode;

//If shortCode is equal to 'rankedMatch' send a matchmakingRequest for a ranked match
if (matchshortCode === "rankedMatch"){
    //Create the request
    var matchRequest = new SparkRequests.MatchmakingRequest();

    //Assign shortCode and skill based on player rank
    matchRequest.matchShortCode = matchshortCode;
    matchRequest.skill = Spark.getPlayer().getScriptData("rank");

    //Send request
    matchRequest.Execute();
}
else if(matchshortCode === "casualMatch"){
    //Create the request
    var matchRequest = new SparkRequests.MatchmakingRequest();

    //Assign shortCode and skill as 0 so all players are matched
    matchRequest.matchShortCode = matchshortCode;
    matchRequest.skill = 0;

    //Send request
    matchRequest.Send();
}

Spark.sendMessageById({"data" : ""}, Spark.getPlayer().getPlayerId())