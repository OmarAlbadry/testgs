//Load the challenge
  var chal = Spark.getChallenge(Spark.getData().challengeInstanceId);
  //Retrieve player Id
  var pId = Spark.getPlayer().getPlayerId();

  //Retrieve the slot
  var cardName = Spark.getData().slotNum;
  //Retrieve the current hand
  var currentHand = chal.getScriptData("currentHand");
  //Retrieve the current player's hand
  var playerHand = currentHand[pId];
  //Get the cards name or type
  var cardObj = playerHand[cardName];

  //Retrieve player stats
  var playerStats = chal.getScriptData("playerStats");

  //Retrieve Mana
  var playerMana = playerStats[pId].currentMana;

  //Is there enough mana to spawn the card?
  if( playerMana >= cardObj.spawnCost){

      var playerStats = chal.getScriptData("playerStats");
      //New mana
      playerStats[pId].currentMana = playerStats[pId].currentMana - cardObj.spawnCost;

      //Retrieve the playing field
      var playField = chal.getScriptData("playField");

      if(cardObj.effect === "Charge"){
          //Set value in the correct position (playField -> Players ID -> The card's name/number) with correct name
          playField[pId][cardName] = {"type" : cardObj.type, "atk" : cardObj.atk, "hp" : cardObj.hp, "maxHP": cardObj.hp, "effect": cardObj.effect, "canAtk": true } ;
      }
      else{
          //Set value in the correct position (playField -> Players ID -> The card's name/number) with correct name
          playField[pId][cardName] = {"type" : cardObj.type, "atk" : cardObj.atk, "hp" : cardObj.hp, "maxHP": cardObj.hp, "effect": cardObj.effect, "canAtk": false } ;
      }
      if(cardObj.effect === "Direct Attack"){
          //Determine enemy Id
          if(Spark.getPlayer().getPlayerId() === chal.getChallengerId()){
          //If equal to challenger, then Id is challenged[0] Id
          var opponentId = chal.getChallengedPlayerIds()[0];
          }
          else{
          //If not equal to challenger then other player Id is challenger Id
          var opponentId = chal.getChallengerId();
          }
          //Set opponent players' health
          playerStats[opponentId].playerHealth = playerStats[opponentId].playerHealth - cardObj.atk;
      }
      if(cardObj.effect === "Taunt"){
          playerStats[pId].tauntProtection = true;
      }
      //Remove that card from current hand
      delete currentHand[pId][cardName];

      //Return script message with card pushed
      Spark.setScriptData("result", "Card " + cardName + " of type " + cardObj.type + " is on the playing field");

      //Save jsons
      chal.setScriptData("currentHand", currentHand);
      chal.setScriptData("playField", playField);
      chal.setScriptData("playerStats", playerStats);
  }
  else{
      //if there isn't enough mana, send error report through scriptData
      Spark.setScriptData("Error", "Not enough mana");
  }